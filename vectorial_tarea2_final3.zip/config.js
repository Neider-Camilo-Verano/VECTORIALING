/* =========================================================
   VECTORIAL - Tarea 2
   Dirección de la API FastAPI cuando la página está publicada en un
   hosting estático (GitHub Pages, Netlify). Ejemplo:
   window.VECTORIAL_API_URL = "https://vectorial-visor.onrender.com";
   Si la página la sirve el propio FastAPI (Render, iniciar.bat) se deja vacío.
========================================================= */

window.VECTORIAL_API_URL = "";
