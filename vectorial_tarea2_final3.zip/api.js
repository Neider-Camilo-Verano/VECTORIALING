/* =========================================================
   VECTORIAL - Tarea 2
   Solicitudes a la API (FastAPI) con fetch()
   Autor: Neider Camilo Verano Vidales
========================================================= */

(function () {
    // Dirección de la API según dónde se abra la página:
    //  - servida por el propio FastAPI (puerto 8000 o Render): rutas relativas
    //  - como archivo o con Live Server: FastAPI local en el puerto 8000
    //  - en un hosting estático: la dirección escrita en config.js (si está vacía, modo directo)
    const API_BASE = (() => {
        if (location.port === "8000") return "";
        if (location.protocol === "file:" || location.port === "5500") return "http://127.0.0.1:8000";
        return (window.VECTORIAL_API_URL || "").replace(/\/+$/, "");
    })();

    // Un servicio gratuito en la nube puede tardar en "despertar"; si no responde en este tiempo se usa el modo directo
    const ESPERA_MAXIMA_MS = 45000;

    // Si el servidor FastAPI no está en ejecución, la página sigue funcionando en "modo directo":
    // el navegador consulta Open-Meteo y datos.gov.co con fetch() y aplica las mismas reglas de la API.
    let modoDirecto = false;

    const URL_DIVIPOLA = "https://www.datos.gov.co/resource/gdxc-w37w.json";
    const URL_ELEVACION = "https://api.open-meteo.com/v1/elevation";
    const MAX_PUNTOS = 100;

    const DEPARTAMENTOS = {
        "05": "Antioquia", "08": "Atlántico", "11": "Bogotá D.C.", "13": "Bolívar", "15": "Boyacá",
        "17": "Caldas", "18": "Caquetá", "19": "Cauca", "20": "Cesar", "23": "Córdoba",
        "25": "Cundinamarca", "27": "Chocó", "41": "Huila", "44": "La Guajira", "47": "Magdalena",
        "50": "Meta", "52": "Nariño", "54": "Norte de Santander", "63": "Quindío", "66": "Risaralda",
        "68": "Santander", "70": "Sucre", "73": "Tolima", "76": "Valle del Cauca", "81": "Arauca",
        "85": "Casanare", "86": "Putumayo", "88": "San Andrés y Providencia", "91": "Amazonas",
        "94": "Guainía", "95": "Guaviare", "97": "Vaupés", "99": "Vichada",
    };
    const DEPARTAMENTO_INICIAL = "63";
    const CENTRO = [4.5339, -75.6811];

    // Respaldo local de los municipios del Quindío (igual a datos/municipios_quindio.json)
    const MUNICIPIOS_QUINDIO = [
        { codigo: "63001", nombre: "Armenia", lat: 4.5339, lng: -75.6811 },
        { codigo: "63111", nombre: "Buenavista", lat: 4.3597, lng: -75.7364 },
        { codigo: "63130", nombre: "Calarcá", lat: 4.5292, lng: -75.6439 },
        { codigo: "63190", nombre: "Circasia", lat: 4.6181, lng: -75.6361 },
        { codigo: "63212", nombre: "Córdoba", lat: 4.3922, lng: -75.6853 },
        { codigo: "63272", nombre: "Filandia", lat: 4.6742, lng: -75.6592 },
        { codigo: "63302", nombre: "Génova", lat: 4.2064, lng: -75.7928 },
        { codigo: "63401", nombre: "La Tebaida", lat: 4.4533, lng: -75.7889 },
        { codigo: "63470", nombre: "Montenegro", lat: 4.5667, lng: -75.75 },
        { codigo: "63548", nombre: "Pijao", lat: 4.3342, lng: -75.7011 },
        { codigo: "63594", nombre: "Quimbaya", lat: 4.6247, lng: -75.7633 },
        { codigo: "63690", nombre: "Salento", lat: 4.6372, lng: -75.5711 },
    ];

    /* Envía la solicitud, interpreta el JSON y traduce los errores a mensajes legibles */
    async function solicitar(ruta, opciones) {
        let respuesta;
        try {
            respuesta = await fetch(API_BASE + ruta, { ...opciones, signal: AbortSignal.timeout(ESPERA_MAXIMA_MS) });
        } catch (error) {
            const sinServidor = new Error(
                "No hay conexión con el servidor FastAPI. Verifica que esté en ejecución (python -m uvicorn servidor.main:app --port 8000).",
            );
            sinServidor.sinServidor = true;
            throw sinServidor;
        }

        let cuerpo = null;
        try {
            cuerpo = await respuesta.json();
        } catch (error) {
            cuerpo = null;
        }

        // Un hosting estático (Netlify, GitHub Pages…) no tiene rutas /api: responde 404/405 o devuelve
        // la página HTML en lugar de JSON. En ese caso se trata igual que un servidor apagado.
        if ((!respuesta.ok && [404, 405, 501].includes(respuesta.status)) || (respuesta.ok && cuerpo === null)) {
            const sinApi = new Error("La API FastAPI no está disponible en esta dirección.");
            sinApi.sinServidor = true;
            throw sinApi;
        }

        if (!respuesta.ok) {
            const detalle = cuerpo && cuerpo.detail;
            if (typeof detalle === "string") throw new Error(detalle);
            if (Array.isArray(detalle)) throw new Error(detalle.map((d) => d.msg).join("; "));
            throw new Error(`Error HTTP ${respuesta.status}`);
        }
        if (cuerpo === null) throw new Error("La respuesta del servidor no tiene formato JSON.");
        return cuerpo;
    }

    /* ===== Modo directo: mismas reglas que servidor/main.py, ejecutadas en el navegador ===== */

    async function pedirJson(url, servicio) {
        let respuesta;
        try {
            respuesta = await fetch(url);
        } catch (error) {
            throw new Error(`No fue posible conectar con el servicio ${servicio}. Revisa la conexión a Internet.`);
        }
        if (!respuesta.ok) throw new Error(`El servicio ${servicio} respondió con error ${respuesta.status}.`);
        try {
            return await respuesta.json();
        } catch (error) {
            throw new Error(`El servicio ${servicio} devolvió una respuesta que no se pudo interpretar.`);
        }
    }

    const sinTildes = (texto) => String(texto).normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();

    // Deja solo los registros del departamento pedido (los nombres de campo se buscan por su texto)
    function extraerDivipola(registros, codigoDepartamento) {
        const resultado = {};
        registros.forEach((registro) => {
            const campos = {};
            Object.keys(registro).forEach((k) => (campos[sinTildes(k)] = registro[k]));
            const claveCodigo = Object.keys(campos).find((k) => (k.includes("cod") || k.includes("c_digo")) && (k.includes("mun") || k.includes("mpio")));
            if (!claveCodigo) return;
            const codigo = String(campos[claveCodigo]).replace(/\D/g, "");
            if (codigo.length !== 5 || !codigo.startsWith(codigoDepartamento)) return;
            const claveNombre = Object.keys(campos).find((k) => (k.includes("nom") || k === "municipio") && !k.includes("cod") && !k.includes("dep"));
            const lat = parseFloat(String(campos.latitud).replace(",", "."));
            const lng = parseFloat(String(campos.longitud).replace(",", "."));
            resultado[codigo] = { nombre: claveNombre ? campos[claveNombre] : null, lat: Number.isFinite(lat) ? lat : null, lng: Number.isFinite(lng) ? lng : null };
        });
        return resultado;
    }

    const titulo = (t) => String(t).toLowerCase().replace(/(^|[\s-])\S/g, (c) => c.toUpperCase());

    async function municipiosDirecto(departamento) {
        if (!DEPARTAMENTOS[departamento]) throw new Error("Código de departamento no válido.");
        const locales = {};
        if (departamento === "63") MUNICIPIOS_QUINDIO.forEach((m) => (locales[m.codigo] = m));

        let oficiales = {};
        try {
            oficiales = extraerDivipola(await pedirJson(`${URL_DIVIPOLA}?$limit=2000`, "datos.gov.co (DIVIPOLA)"), departamento);
        } catch (error) {
            if (!Object.keys(locales).length) throw error;
        }

        const features = [];
        [...new Set([...Object.keys(locales), ...Object.keys(oficiales)])].sort().forEach((codigo) => {
            const local = locales[codigo];
            const oficial = oficiales[codigo];
            const lat = (local && local.lat) || (oficial && oficial.lat);
            const lng = (local && local.lng) || (oficial && oficial.lng);
            if (lat === null || lat === undefined || lng === null || lng === undefined) return;
            features.push({
                type: "Feature",
                geometry: { type: "Point", coordinates: [lng, lat] }, // GeoJSON: [longitud, latitud]
                properties: {
                    codigo_dane: codigo,
                    nombre: oficial && oficial.nombre ? titulo(oficial.nombre) : local.nombre,
                    departamento: DEPARTAMENTOS[departamento],
                    verificado_dane: Boolean(oficial),
                },
            });
        });
        return {
            type: "FeatureCollection",
            features,
            metadatos: {
                departamento: { codigo: departamento, nombre: DEPARTAMENTOS[departamento] },
                fuente_codigos: Object.keys(oficiales).length ? "DANE - DIVIPOLA (datos.gov.co)" : "Tabla local (datos.gov.co no disponible)",
                fuente_coordenadas: Object.keys(locales).length ? "Cabeceras municipales (referencia local)" : "DIVIPOLA (datos.gov.co)",
                total: features.length,
            },
        };
    }

    async function elevacionesDirecto(puntos) {
        if (!Array.isArray(puntos) || puntos.length < 1 || puntos.length > MAX_PUNTOS) throw new Error(`Se requieren entre 1 y ${MAX_PUNTOS} puntos por solicitud.`);
        puntos.forEach((p, i) => {
            if (!Number.isFinite(p.lat) || !Number.isFinite(p.lng) || Math.abs(p.lat) > 90 || Math.abs(p.lng) > 180) throw new Error(`El punto ${i + 1} tiene coordenadas fuera de rango.`);
        });
        const lat = puntos.map((p) => p.lat.toFixed(5)).join(",");
        const lng = puntos.map((p) => p.lng.toFixed(5)).join(",");
        const datos = await pedirJson(`${URL_ELEVACION}?latitude=${lat}&longitude=${lng}`, "Open-Meteo (elevación)");
        if (!datos || !Array.isArray(datos.elevation) || datos.elevation.length !== puntos.length) throw new Error("El servicio de elevación devolvió un número de cotas distinto al solicitado.");
        return { elevaciones: datos.elevation, fuente: "Open-Meteo (modelo digital de elevación de 90 m)" };
    }

    // Usa la API FastAPI; si el servidor no está en ejecución pasa al modo directo
    async function consultar(viaApi, viaDirecta) {
        if (!modoDirecto) {
            try {
                return await viaApi();
            } catch (error) {
                if (!error.sinServidor) throw error;
                modoDirecto = true;
            }
        }
        return viaDirecta();
    }

    const listaDepartamentos = () =>
        Object.entries(DEPARTAMENTOS)
            .map(([codigo, nombre]) => ({ codigo, nombre }))
            .sort((a, b) => a.nombre.localeCompare(b.nombre, "es"));

    window.VectorialAPI = {
        modoDirecto: () => modoDirecto,

        // GET /api/configuracion -> estado del servidor y valores iniciales
        configuracion: () =>
            consultar(
                () => solicitar("/api/configuracion"),
                async () => ({ estado: "directo", departamento: { codigo: DEPARTAMENTO_INICIAL, nombre: DEPARTAMENTOS[DEPARTAMENTO_INICIAL] }, centro: CENTRO }),
            ),

        // GET /api/departamentos -> lista de departamentos con su código DANE
        departamentos: () =>
            consultar(
                () => solicitar("/api/departamentos"),
                async () => ({ departamentos: listaDepartamentos() }),
            ),

        // GET /api/municipios?departamento=63 -> GeoJSON con los municipios de ese departamento
        municipios: (departamento) =>
            consultar(
                () => solicitar(`/api/municipios?departamento=${encodeURIComponent(departamento)}`),
                () => municipiosDirecto(departamento),
            ),

        // POST /api/elevacion -> cotas de una lista de puntos [{lat, lng}, ...]
        elevaciones: (puntos) =>
            consultar(
                () =>
                    solicitar("/api/elevacion", {
                        method: "POST",
                        headers: { "Content-Type": "application/json" },
                        body: JSON.stringify({ puntos }),
                    }),
                () => elevacionesDirecto(puntos),
            ),

        // Cuando hay más de 100 puntos se envían varias solicitudes seguidas y se unen las cotas
        elevacionesPorLotes: async (puntos, tamano = 100, alAvanzar = () => {}) => {
            const cotas = [];
            for (let i = 0; i < puntos.length; i += tamano) {
                const respuesta = await window.VectorialAPI.elevaciones(puntos.slice(i, i + tamano));
                if (!Array.isArray(respuesta.elevaciones)) throw new Error("La API devolvió las cotas con un formato inesperado.");
                cotas.push(...respuesta.elevaciones);
                alAvanzar(Math.min(i + tamano, puntos.length), puntos.length);
            }
            return cotas;
        },
    };
})();
