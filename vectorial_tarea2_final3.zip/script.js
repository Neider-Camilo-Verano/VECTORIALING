/* VECTORIAL - Herramienta geomática: intersección de dos líneas */
const $ = (id) => document.getElementById(id);
const resultBox = $("resultBox"),
    svgLine1 = $("svgLine1"),
    svgLine2 = $("svgLine2"),
    intersectionPoint = $("intersectionPoint");
const IDS = ["x1", "y1", "x2", "y2", "x3", "y3", "x4", "y4"];
const PLACEHOLDER = `<div class="result-placeholder"><div class="crosshair">+</div><h3>Esperando coordenadas</h3><p>Ingresa los cuatro puntos para ejecutar el procesamiento geomático.</p></div>`;
/* ===== MENÚ RESPONSIVE ===== */
$("menuToggle").addEventListener("click", () => $("navigation").classList.toggle("active"));
document
    .querySelectorAll(".navigation a")
    .forEach((a) => a.addEventListener("click", () => $("navigation").classList.remove("active")));
/* ===== ENTRADA Y VALIDACIÓN ===== */
// Number("") da 0, por eso los campos vacíos se marcan como NaN
const getCoordinates = () =>
    IDS.map((id) => {
        const v = $(id).value.trim();
        return v === "" ? NaN : Number(v);
    });
const validateCoordinates = (values) => values.every(Number.isFinite);
/* ===== INTERSECCIÓN POR DETERMINANTES ===== */
function calculateIntersection() {
    const [x1, y1, x2, y2, x3, y3, x4, y4] = getCoordinates();
    if (!validateCoordinates([x1, y1, x2, y2, x3, y3, x4, y4]))
        return showError("Debes ingresar las coordenadas de los cuatro puntos.");
    if ((x1 === x2 && y1 === y2) || (x3 === x4 && y3 === y4))
        return showError("Cada línea debe estar definida por dos puntos diferentes.");
    // den = (x1-x2)(y3-y4) - (y1-y2)(x3-x4)
    const den = (x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4);
    const tolerance = 1e-10;
    // Líneas paralelas o coincidentes
    if (Math.abs(den) < tolerance) {
        const cross = (x2 - x1) * (y3 - y1) - (y2 - y1) * (x3 - x1);
        return showError(
            Math.abs(cross) < tolerance
                ? "Las dos líneas son coincidentes: pertenecen a la misma recta."
                : "Las dos líneas son paralelas y no presentan un punto de intersección.",
        );
    }
    // Punto de intersección
    const d1 = x1 * y2 - y1 * x2,
        d2 = x3 * y4 - y3 * x4;
    const ix = (d1 * (x3 - x4) - (x1 - x2) * d2) / den;
    const iy = (d1 * (y3 - y4) - (y1 - y2) * d2) / den;
    // t: posición sobre AB, u: posición sobre CD
    const t = ((x1 - x3) * (y3 - y4) - (y1 - y3) * (x3 - x4)) / den;
    const u = ((x1 - x3) * (y1 - y2) - (y1 - y3) * (x1 - x2)) / den;
    showResult(ix, iy, t >= 0 && t <= 1, u >= 0 && u <= 1);
    updateMap(x1, y1, x2, y2, x3, y3, x4, y4, ix, iy);
}
/* ===== RESULTADO Y ERROR ===== */
function showResult(x, y, onAB, onCD) {
    const fmt = new Intl.NumberFormat("es-CO", { minimumFractionDigits: 3, maximumFractionDigits: 3 });
    const msg =
        onAB && onCD
            ? "El punto de intersección se encuentra dentro de ambos segmentos."
            : onAB
              ? "La intersección pertenece al segmento AB, pero no al segmento CD."
              : onCD
                ? "La intersección pertenece al segmento CD, pero no al segmento AB."
                : "La intersección se encuentra sobre la prolongación de ambos segmentos.";
    resultBox.innerHTML = `<div class="result-success">
<span class="result-label">PUNTO DE INTERSECCIÓN</span>
<div class="coordinates-result">
<div class="coordinate-result"><strong>${fmt.format(x)}</strong><span>COORDENADA X</span></div>
<div class="coordinate-result"><strong>${fmt.format(y)}</strong><span>COORDENADA Y</span></div>
</div>
<div class="result-message">${msg}</div>
</div>`;
}
function showError(message) {
    resultBox.innerHTML = `<div class="result-placeholder"><div class="crosshair">!</div><h3>No fue posible procesar</h3><p>${message}</p></div>`;
}
/* ===== MAPA SVG ===== */
function setLine(line, xa, ya, xb, yb) {
    line.setAttribute("x1", xa);
    line.setAttribute("y1", ya);
    line.setAttribute("x2", xb);
    line.setAttribute("y2", yb);
}
function updateMap(x1, y1, x2, y2, x3, y3, x4, y4, ix, iy) {
    const xs = [x1, x2, x3, x4, ix],
        ys = [y1, y2, y3, y4, iy],
        margin = 0.15;
    const minX = Math.min(...xs),
        maxX = Math.max(...xs),
        minY = Math.min(...ys),
        maxY = Math.max(...ys);
    const rx = Math.max(maxX - minX, 1),
        ry = Math.max(maxY - minY, 1);
    const x0 = minX - rx * margin,
        x1e = maxX + rx * margin;
    const y0 = minY - ry * margin,
        y1e = maxY + ry * margin;
    const cx = (x) => ((x - x0) / (x1e - x0)) * 500;
    const cy = (y) => 300 - ((y - y0) / (y1e - y0)) * 300;
    setLine(svgLine1, cx(x1), cy(y1), cx(x2), cy(y2));
    setLine(svgLine2, cx(x3), cy(y3), cx(x4), cy(y4));
    intersectionPoint.setAttribute("cx", cx(ix));
    intersectionPoint.setAttribute("cy", cy(iy));
}
/* ===== EJEMPLO, LIMPIAR, CALCULAR, ENTER ===== */
$("exampleBtn").addEventListener("click", () => {
    [0, 0, 10, 10, 0, 10, 10, 0].forEach((v, i) => ($(IDS[i]).value = v));
    calculateIntersection();
});
$("clearBtn").addEventListener("click", () => {
    document.querySelectorAll(".input-grid input").forEach((i) => (i.value = ""));
    resultBox.innerHTML = PLACEHOLDER;
    setLine(svgLine1, 50, 250, 450, 50);
    setLine(svgLine2, 50, 50, 450, 250);
    intersectionPoint.setAttribute("cx", 250);
    intersectionPoint.setAttribute("cy", 150);
});
$("calculateBtn").addEventListener("click", calculateIntersection);
document.querySelectorAll(".input-grid input").forEach((i) =>
    i.addEventListener("keydown", (e) => {
        if (e.key === "Enter") calculateIntersection();
    }),
);
