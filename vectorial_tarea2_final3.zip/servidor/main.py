"""
VECTORIAL - Tarea 2
API del visor territorial (FastAPI). Funciona para cualquier punto del mundo en
el análisis de terreno y para todos los departamentos de Colombia en municipios.

Esta API hace de intermediaria entre la página (front-end) y los servicios
externos (back-end):

    navegador (JavaScript) -> FastAPI -> datos.gov.co / Open-Meteo

Servicios externos consultados:
  - DIVIPOLA (DANE) publicada en datos.gov.co: códigos y nombres de municipios.
  - Open-Meteo Elevation API: cota del terreno de un conjunto de puntos.

Ejecución (desde la carpeta raíz del proyecto):
    python -m uvicorn servidor.main:app --port 8000
Página: http://127.0.0.1:8000
Documentación automática de la API: http://127.0.0.1:8000/docs
"""

import json
import time
import unicodedata
from datetime import datetime, timezone
from pathlib import Path

import httpx
from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

# ---------------------------------------------------------------------------
# Configuración
# ---------------------------------------------------------------------------

RAIZ = Path(__file__).resolve().parent.parent
ARCHIVO_MUNICIPIOS = RAIZ / "datos" / "municipios_quindio.json"

# Departamentos de Colombia (códigos DANE)
DEPARTAMENTOS = {
    "05": "Antioquia", "08": "Atlántico", "11": "Bogotá D.C.", "13": "Bolívar", "15": "Boyacá",
    "17": "Caldas", "18": "Caquetá", "19": "Cauca", "20": "Cesar", "23": "Córdoba",
    "25": "Cundinamarca", "27": "Chocó", "41": "Huila", "44": "La Guajira", "47": "Magdalena",
    "50": "Meta", "52": "Nariño", "54": "Norte de Santander", "63": "Quindío", "66": "Risaralda",
    "68": "Santander", "70": "Sucre", "73": "Tolima", "76": "Valle del Cauca", "81": "Arauca",
    "85": "Casanare", "86": "Putumayo", "88": "San Andrés y Providencia", "91": "Amazonas",
    "94": "Guainía", "95": "Guaviare", "97": "Vaupés", "99": "Vichada",
}

# Departamento y centro con los que arranca el visor (el usuario puede cambiarlos)
DEPARTAMENTO_INICIAL = "63"
CENTRO = [4.5339, -75.6811]

URL_DIVIPOLA = "https://www.datos.gov.co/resource/gdxc-w37w.json"
URL_ELEVACION = "https://api.open-meteo.com/v1/elevation"

TIEMPO_ESPERA = 20  # segundos
MAX_PUNTOS = 100  # límite de puntos por consulta de elevación (el front-end envía lotes)

app = FastAPI(
    title="API VECTORIAL",
    description="Municipios (DANE) y elevación del terreno.",
    version="1.0.0",
)

# La API solo entrega datos de lectura, por eso se permite el acceso desde
# cualquier origen (por ejemplo, Live Server en otro puerto).
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["GET", "POST"], allow_headers=["*"])

# ---------------------------------------------------------------------------
# Utilidades
# ---------------------------------------------------------------------------

_cache = {}


def cache_get(clave, vigencia):
    """Devuelve un valor guardado si aún no ha vencido (vigencia en segundos)."""
    guardado = _cache.get(clave)
    if guardado and time.time() - guardado[0] < vigencia:
        return guardado[1]
    return None


def cache_set(clave, valor):
    _cache[clave] = (time.time(), valor)


async def consultar_json(url, parametros=None):
    """Hace una solicitud GET a un servicio externo y devuelve el JSON recibido."""
    async with httpx.AsyncClient(timeout=TIEMPO_ESPERA, headers={"User-Agent": "VECTORIAL-academico/1.0"}) as cliente:
        respuesta = await cliente.get(url, params=parametros)
        respuesta.raise_for_status()
        return respuesta.json()


def error_servicio(servicio, error):
    """Convierte los errores de un servicio externo en una respuesta HTTP clara."""
    if isinstance(error, httpx.TimeoutException):
        return HTTPException(504, f"El servicio {servicio} tardó demasiado en responder.")
    if isinstance(error, httpx.HTTPStatusError):
        motivo = ""
        try:
            motivo = error.response.json().get("reason", "")
        except Exception:
            pass
        return HTTPException(502, f"El servicio {servicio} respondió con error {error.response.status_code}. {motivo}".strip())
    if isinstance(error, httpx.HTTPError):
        return HTTPException(502, f"No fue posible conectar con el servicio {servicio}.")
    return HTTPException(502, f"El servicio {servicio} devolvió una respuesta que no se pudo interpretar.")


def normalizar(texto):
    """Minúsculas y sin tildes, para comparar nombres de campos."""
    texto = unicodedata.normalize("NFKD", str(texto))
    return "".join(c for c in texto if not unicodedata.combining(c)).lower()


# ---------------------------------------------------------------------------
# Municipios (DIVIPOLA - DANE)
# ---------------------------------------------------------------------------


def leer_tabla_local():
    with open(ARCHIVO_MUNICIPIOS, encoding="utf-8") as archivo:
        return json.load(archivo)


def extraer_divipola(registros, codigo_departamento):
    """
    Toma los registros de DIVIPOLA y deja solo los del departamento pedido
    (código de municipio que empieza por el código del departamento). Los nombres de los campos se buscan por su texto porque
    pueden variar entre versiones del conjunto de datos.
    """
    resultado = {}
    for registro in registros:
        campos = {normalizar(k): v for k, v in registro.items()}
        codigo = next(
            (v for k, v in campos.items() if ("cod" in k or "c_digo" in k) and ("mun" in k or "mpio" in k)),
            None,
        )
        if codigo is None:
            continue
        codigo = "".join(c for c in str(codigo) if c.isdigit())
        if len(codigo) != 5 or not codigo.startswith(codigo_departamento):
            continue
        nombre = next(
            (v for k, v in campos.items() if ("nom" in k or k == "municipio") and "cod" not in k and "dep" not in k),
            None,
        )
        try:
            lat, lng = (float(str(campos[c]).replace(",", ".")) for c in ("latitud", "longitud"))
        except (KeyError, TypeError, ValueError):
            lat = lng = None
        resultado[codigo] = {"nombre": nombre, "lat": lat, "lng": lng}
    return resultado


@app.get("/api/departamentos", tags=["Municipios"])
def departamentos():
    """Lista de departamentos de Colombia con su código DANE."""
    lista = [{"codigo": c, "nombre": n} for c, n in sorted(DEPARTAMENTOS.items(), key=lambda x: x[1])]
    return {"departamentos": lista}


@app.get("/api/municipios", tags=["Municipios"])
async def municipios(departamento: str = Query(DEPARTAMENTO_INICIAL, description="Código DANE del departamento, por ejemplo 63")):
    """GeoJSON (puntos) con los municipios de un departamento y su código DANE."""
    if departamento not in DEPARTAMENTOS:
        raise HTTPException(422, "Código de departamento no válido. Consulta /api/departamentos.")

    clave = f"municipios-{departamento}"
    guardado = cache_get(clave, 24 * 3600)
    if guardado:
        return guardado

    # La tabla local (respaldo) solo existe para el Quindío
    locales = {m["codigo"]: m for m in leer_tabla_local()} if departamento == "63" else {}
    oficiales = {}
    try:
        registros = await consultar_json(URL_DIVIPOLA, {"$limit": 2000})
        oficiales = extraer_divipola(registros, departamento)
    except Exception as error:
        # Si datos.gov.co no responde se usa la tabla local cuando existe
        if not locales:
            raise error_servicio("datos.gov.co (DIVIPOLA)", error)
        oficiales = {}

    codigos = sorted(set(locales) | set(oficiales))
    elementos = []
    for codigo in codigos:
        local, oficial = locales.get(codigo), oficiales.get(codigo)
        lat = (local or {}).get("lat") or (oficial or {}).get("lat")
        lng = (local or {}).get("lng") or (oficial or {}).get("lng")
        if lat is None or lng is None:
            continue
        if oficial and oficial.get("nombre"):
            nombre = str(oficial["nombre"]).title()
        else:
            nombre = (local or {}).get("nombre")
        elementos.append(
            {
                "type": "Feature",
                "geometry": {"type": "Point", "coordinates": [lng, lat]},  # GeoJSON: [longitud, latitud]
                "properties": {
                    "codigo_dane": codigo,
                    "nombre": nombre,
                    "departamento": DEPARTAMENTOS[departamento],
                    "verificado_dane": oficial is not None,
                },
            }
        )

    if oficiales:
        fuente_codigos = "DANE - DIVIPOLA (datos.gov.co)"
    else:
        fuente_codigos = "Tabla local (datos.gov.co no disponible)"
    respuesta = {
        "type": "FeatureCollection",
        "features": elementos,
        "metadatos": {
            "departamento": {"codigo": departamento, "nombre": DEPARTAMENTOS[departamento]},
            "fuente_codigos": fuente_codigos,
            "fuente_coordenadas": "Cabeceras municipales (referencia local)" if locales else "DIVIPOLA (datos.gov.co)",
            "total": len(elementos),
            "consultado": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        },
    }
    cache_set(clave, respuesta)
    return respuesta


# ---------------------------------------------------------------------------
# Elevación (Open-Meteo)
# ---------------------------------------------------------------------------


class Punto(BaseModel):
    lat: float = Field(ge=-90, le=90)
    lng: float = Field(ge=-180, le=180)


class SolicitudElevacion(BaseModel):
    puntos: list[Punto] = Field(min_length=1, max_length=MAX_PUNTOS)


@app.post("/api/elevacion", tags=["Elevación"])
async def elevacion(solicitud: SolicitudElevacion):
    """Cota (m s. n. m.) de una lista de puntos (cualquier lugar del mundo)."""
    parametros = {
        "latitude": ",".join(f"{p.lat:.5f}" for p in solicitud.puntos),
        "longitude": ",".join(f"{p.lng:.5f}" for p in solicitud.puntos),
    }
    try:
        datos = await consultar_json(URL_ELEVACION, parametros)
    except Exception as error:
        raise error_servicio("Open-Meteo (elevación)", error)

    cotas = datos.get("elevation") if isinstance(datos, dict) else None
    if not isinstance(cotas, list) or len(cotas) != len(solicitud.puntos):
        raise HTTPException(502, "El servicio de elevación devolvió un número de cotas distinto al solicitado.")
    return {"elevaciones": cotas, "fuente": "Open-Meteo (modelo digital de elevación de 90 m)"}


# ---------------------------------------------------------------------------
# Configuración y estado
# ---------------------------------------------------------------------------


@app.get("/api/configuracion", tags=["Estado"])
def configuracion():
    """Valores iniciales del visor; también sirve para comprobar que la API responde."""
    return {"estado": "ok", "departamento": {"codigo": DEPARTAMENTO_INICIAL, "nombre": DEPARTAMENTOS[DEPARTAMENTO_INICIAL]}, "centro": CENTRO}


# La página (index.html, estilos, scripts e imágenes) se sirve desde la misma
# dirección. Debe ir al final para no tapar las rutas /api.
app.mount("/", StaticFiles(directory=RAIZ, html=True), name="sitio")
