#!/bin/bash
cd "$(dirname "$0")"
if [ ! -d .venv ]; then
    python3 -m venv .venv
fi
source .venv/bin/activate
pip install -r servidor/requirements.txt
echo "Abrir http://127.0.0.1:8000 en el navegador"
python -m uvicorn servidor.main:app --port 8000
