# VECTORIAL | Ingeniería Topográfica y Geomática — Tarea 2

Autor: Neider Camilo Verano Vidales

Proyecto web de la empresa VECTORIAL (Tarea 1) ampliado con un visor cartográfico Leaflet de uso general (cualquier lugar del mundo para el terreno y todos los departamentos de Colombia para los municipios), conectado a una API desarrollada con FastAPI. Los archivos de la Tarea 1 (`index.html`, `style.css`, `script.js`) se conservan tal como se entregaron; en `index.html` solo se agregó la sección del visor, el enlace "Visor" del menú y las referencias a los archivos nuevos. El trabajo nuevo está en `visor.css`, `visor.js`, `api.js`, `analisis.js` y la carpeta `servidor/`.

## 1. Propósito de la aplicación

Visor territorial para el **análisis preliminar del terreno en obras lineales** (vías, redes, canales). Con él se puede:

- Consultar los municipios de cualquier departamento de Colombia con su código DANE, su cota y su piso térmico, y filtrarlos por nombre o piso térmico.
- Marcar puntos con clics sobre el mapa o escribiendo sus coordenadas.
- Marcar un alineamiento sobre el mapa y obtener su perfil longitudinal: longitud, desnivel, pendientes, municipio más cercano y una evaluación preliminar del corredor.
- Descargar el alineamiento en formato GeoJSON, con el resumen del perfil en sus propiedades.
- Calcular el mapa de pendientes de la zona que se ve en pantalla.
- Revisar el territorio con distintas capas: calles de OpenStreetMap (base principal), satélite, calles y topográfico de Esri, relieve sombreado y uso del suelo. El mapa va arriba en formato horizontal y los controles (alineamiento, municipios y análisis del terreno) están debajo.

### Relación con los servicios de VECTORIAL

| Servicio de la empresa | Qué hace el visor |
|---|---|
| Levantamientos topográficos | Perfil longitudinal del alineamiento, distancias, desnivel y pendientes |
| Análisis espacial | Mapa de pendientes del terreno, uso del suelo, municipios y piso térmico |
| Georreferenciación | Coordenadas de cada punto y exportación del alineamiento en GeoJSON |

## 2. Arquitectura (Front-end ↔ API ↔ Back-end)

```
Usuario (clic / botón)
   → JavaScript (api.js, fetch)
   → API FastAPI (servidor/main.py)
   → Servicio externo (datos.gov.co, Open-Meteo)
   → Respuesta JSON / GeoJSON
   → Procesamiento en JavaScript (analisis.js)
   → Visualización en Leaflet, tablas y gráfico (visor.js)
```

**Modo directo.** Si el servidor FastAPI no está en ejecución, `api.js` lo detecta y la página sigue funcionando: el propio navegador consulta Open-Meteo y datos.gov.co con `fetch()` y aplica las mismas validaciones. El panel del visor indica en qué modo está ("Servidor conectado" o "Modo directo"). Esto también ocurre cuando la página se publica en un hosting estático (Netlify, GitHub Pages), donde no existen las rutas `/api`. Así el proyecto se puede probar con solo abrir `index.html`, con Live Server o desde un hosting, sin instalar nada.

La API de FastAPI valida los datos de entrada, consulta el servicio externo, maneja sus errores y devuelve una respuesta limpia. Los cálculos se hacen en JavaScript. Las capas de mapa (teselas y WMS) las pide directamente el navegador a su proveedor.

## 3. Servicios utilizados

| Servicio | Dirección | Uso |
|---|---|---|
| DIVIPOLA - DANE (datos.gov.co) | https://www.datos.gov.co/resource/gdxc-w37w.json | Códigos y nombres de los municipios (vía la API) |
| Open-Meteo Elevation API | https://api.open-meteo.com/v1/elevation (docs: https://open-meteo.com/en/docs/elevation-api) | Cota del terreno (vía la API) |
| OpenStreetMap | https://tile.openstreetmap.org/{z}/{x}/{y}.png (política de uso: https://operations.osmfoundation.org/policies/tiles/) | Base principal del mapa |
| Esri World Imagery, World Street Map y World Topo Map | https://server.arcgisonline.com/ArcGIS/rest/services/ | Bases satelital, de calles y topográfica |
| Esri World Hillshade | https://elevation3d.arcgis.com/arcgis/rest/services/Elevation/World_Hillshade/MapServer | Capa de relieve sombreado |
| ESA WorldCover 2021 (Terrascope, WMS) | https://mapproxy.terrascope.be/mapproxy/service (capa `esa-worldcover-map-10m-2021-v2_map`; docs: https://docs.terrascope.be) | Capa de cobertura y uso del suelo |

Ninguno requiere clave. No hay credenciales en los archivos.

## 4. Endpoints de la API propia

| Método y ruta | Datos enviados | Datos recibidos |
|---|---|---|
| `GET /api/configuracion` | — | Estado, departamento y centro con los que arranca el visor |
| `GET /api/departamentos` | — | Lista de departamentos con su código DANE |
| `GET /api/municipios` | `departamento` (código DANE, por ejemplo `63`) | GeoJSON de puntos: `codigo_dane`, `nombre`, `verificado_dane` |
| `POST /api/elevacion` | `{"puntos": [{"lat": 4.53, "lng": -75.68}, ...]}` (máx. 100 por solicitud; latitud -90..90, longitud -180..180) | `{"elevaciones": [1603.0, ...]}` |

Cuando se necesitan más de 100 cotas (malla de pendientes) `api.js` envía varias solicitudes seguidas y une los resultados.

Documentación interactiva: http://127.0.0.1:8000/docs

## 5. Procesamiento realizado en JavaScript (`analisis.js`)

- Distancias con la fórmula de Haversine y longitud acumulada del alineamiento.
- Interpolación de N puntos de muestreo equidistantes sobre el trazado.
- Perfil: desnivel, ascenso y descenso acumulados, pendiente media y máxima, y porcentaje de la longitud en cada clase de pendiente (suave < 5 %, moderada 5–10 %, fuerte > 10 %).
- Evaluación preliminar del corredor según el porcentaje de longitud con pendiente fuerte (favorable < 10 %, con tramos exigentes 10–30 %, exigente ≥ 30 %). Es un criterio de referencia definido para este visor.
- Mapa de pendientes: malla de n × n celdas sobre la vista del mapa, cota de cada centro de celda, pendiente por diferencias centrales y clasificación en cinco clases (< 5, 5–10, 10–20, 20–35 y > 35 %).
- Validación de coordenadas escritas por el usuario (números, rangos) y filtros de la tabla de municipios.
- Municipio más cercano a cada punto (entre los municipios cargados; si está a más de 150 km se indica que no aplica) y piso térmico según la cota (cálido < 1000 m, templado 1000–2000 m, frío 2000–3000 m, páramo > 3000 m).
- Construcción del GeoJSON del alineamiento (`LineString`, coordenadas `[longitud, latitud]`) para la descarga.
- Validación de las respuestas (GeoJSON válido, cotas numéricas y en la cantidad esperada) y escape de textos antes de mostrarlos.

## 6. Cómo ejecutar y probar

**Opción A, sin instalar nada (modo directo):** descomprimir la carpeta y abrirla con **Live Server** de Visual Studio Code (clic derecho en `index.html` → *Open with Live Server*), o abrir el enlace publicado. Solo requiere conexión a Internet. **No abrir `index.html` con doble clic:** OpenStreetMap bloquea las teselas a las páginas abiertas como archivo (`file://`); en ese caso el visor lo avisa y usa la base satelital de Esri.

**Opción B, con la API FastAPI (arquitectura completa Front-end ↔ API ↔ Back-end):** requiere Python 3.9 o superior y conexión a Internet.

**Windows:** doble clic en `iniciar.bat`.

**Mac / Linux:** `bash iniciar.sh`

**Manual** (desde la carpeta del proyecto):

```
pip install -r servidor/requirements.txt
python -m uvicorn servidor.main:app --port 8000
```

Después abrir http://127.0.0.1:8000 en el navegador y entrar a la sección **Visor**.

Pruebas sugeridas:

1. Elegir un departamento y pulsar **Cargar municipios**; en la pestaña **Municipios (DANE)** revisar código, cota y piso térmico, y probar los filtros.
2. Hacer clic en el mapa (o escribir latitud y longitud y pulsar **Agregar**) para marcar 2 o más puntos y pulsar **Calcular perfil**; pasar el mouse sobre el gráfico para ver el punto en el mapa. Pulsar **Descargar alineamiento (GeoJSON)**.
3. Acercar el mapa a una zona (la malla exige celdas de hasta 5 km; si la vista es muy amplia el visor lo indica) y pulsar **Calcular pendientes de la vista**; revisar la leyenda y la pestaña **Pendientes del terreno**.
4. En el menú de capas del mapa (arriba a la derecha) cambiar entre satélite, calles y topográfico, y activar **Relieve sombreado** y **Uso del suelo** (aparece su leyenda).


### Publicación con la API en línea (opcional)

Los hostings estáticos (Netlify, GitHub Pages) no ejecutan Python, por eso allí el visor trabaja en modo directo. Para publicar el sitio junto con la API FastAPI se puede usar un servicio que ejecute Python, por ejemplo Render:

1. Subir la carpeta del proyecto a un repositorio de GitHub.
2. En Render: *New* → *Web Service* → elegir el repositorio (el archivo `render.yaml` ya trae la configuración).
3. Comando de construcción: `pip install -r servidor/requirements.txt`. Comando de inicio: `uvicorn servidor.main:app --host 0.0.0.0 --port $PORT`.
4. Al abrir la dirección que entrega Render, el panel del visor indica "Servidor conectado", porque FastAPI también sirve la página.

**Sitio en GitHub Pages / Netlify y API en Render.** Si el sitio se deja en un hosting estático, se escribe la dirección de Render en `config.js` (`window.VECTORIAL_API_URL = "https://vectorial-visor.onrender.com";`) y se vuelve a publicar. Con eso el visor usa la API FastAPI y el panel indica "Servidor conectado". Si la API no responde en 45 segundos, el visor pasa solo al modo directo. En el plan gratuito el servicio se duerme tras un tiempo sin uso y la primera carga puede tardar.

## 7. Dependencias externas

- Python: FastAPI, Uvicorn y HTTPX (`servidor/requirements.txt`).
- Leaflet 1.9.4, incluida de forma local en `libs/leaflet/`.
- Conexión a Internet para la API, los mapas base y las capas temáticas.

## 8. Limitaciones y atribución

- Las cotas provienen de un modelo digital de elevación de unos 90 m de resolución: el mapa de pendientes y el perfil sirven para análisis preliminar y no reemplazan un levantamiento topográfico. Si el tamaño de celda es menor a 90 m el visor lo advierte.
- El mapa de pendientes se calcula sobre la zona visible y solo si las celdas no superan los 5 km de lado.
- Los municipios solo están disponibles para Colombia (DIVIPOLA). Fuera de Colombia funcionan el perfil, las pendientes y las capas, pero no el municipio más cercano.
- Los códigos, nombres y coordenadas de los municipios se toman de DIVIPOLA. Solo para el Quindío existe un respaldo local (`datos/municipios_quindio.json`) que se usa si el servicio no responde; en los demás departamentos, sin el servicio no hay municipios. La columna "Fuente del nombre" de la tabla lo indica.
- La capa de uso del suelo es global (10 m) y no sustituye la cartografía oficial de coberturas del IDEAM / IGAC.
- Las capas externas dependen de la disponibilidad de cada proveedor.
- OpenStreetMap exige que la petición indique la página de origen. El visor lo configura (`referrerPolicy: "origin"`) y, antes de usarlo, prueba una tesela; si está bloqueado cambia automáticamente a la base de Esri y muestra un aviso.
- Mapa base © colaboradores de OpenStreetMap. Otras bases © Esri, Maxar, Earthstar Geographics, USGS, NGA, NASA, CGIAR y colaboradores de OpenStreetMap. Relieve: Esri, USGS, NGA, NASA, CGIAR. Cobertura del suelo: © ESA WorldCover 2021 (CC BY 4.0), Terrascope. Elevación: Open-Meteo. Municipios: DANE (datos.gov.co).

## 9. Estructura

```
index.html, style.css, script.js      Tarea 1 (sin cambios)
config.js                             Dirección de la API cuando el sitio está en un hosting estático
visor.css, visor.js                   Estilos y lógica del visor Leaflet
api.js                                Solicitudes fetch a la API
analisis.js                           Procesamiento de las respuestas
servidor/main.py                      API FastAPI
servidor/requirements.txt             Dependencias de Python
datos/municipios_quindio.json         Respaldo local de municipios
libs/leaflet/                         Leaflet (local)
iniciar.bat, iniciar.sh               Arranque del servidor
render.yaml                           Configuración para publicar la API en Render
*.png                                 Imágenes del sitio
```
