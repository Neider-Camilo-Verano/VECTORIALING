/* =========================================================
   VECTORIAL - Tarea 2
   Visor cartográfico (Leaflet) conectado a la API
   Autor: Neider Camilo Verano Vidales

   Requiere cargar antes: Leaflet, api.js y analisis.js
========================================================= */

(function () {
    const el = (id) => document.getElementById(id);
    const A = window.VectorialAnalisis;
    const API = window.VectorialAPI;
    const esc = A.escaparHtml;

    function estado(texto, tipo = "") {
        el("visorStatus").textContent = texto;
        el("visorStatus").className = "viewer-status " + tipo;
    }

    // Si Leaflet no cargó se avisa en lugar de dejar la página rota
    if (typeof L === "undefined") {
        estado("No se pudo cargar Leaflet (libs/leaflet). Revisa que la carpeta del proyecto esté completa.", "error");
        return;
    }

    /* =====================================================
       1. MAPA Y BASES CARTOGRÁFICAS
    ===================================================== */

    // Vista inicial (la API la confirma en /api/configuracion); el mapa se puede mover a cualquier lugar
    const CENTRO_INICIAL = [4.5339, -75.6811];

    const map = L.map("map", { minZoom: 3, worldCopyJump: true }).setView(CENTRO_INICIAL, 11);

    // OpenStreetMap es la base principal. referrerPolicy "origin" hace que cada petición indique la página
    // de origen, que es lo que exige su política de uso de teselas.
    const osm = L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", {
        maxZoom: 19,
        referrerPolicy: "origin",
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
    }).addTo(map);

    // Bases de Esri (ArcGIS Online)
    const ATRIBUCION_ESRI = "Esri, Maxar, Earthstar Geographics, USGS, NGA, NASA, CGIAR, OpenStreetMap contributors";

    const satelite = L.tileLayer("https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}", {
        maxZoom: 18,
        attribution: "Imágenes: " + ATRIBUCION_ESRI,
    });

    const calles = L.tileLayer("https://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer/tile/{z}/{y}/{x}", {
        maxZoom: 18,
        attribution: "Mapa de calles: " + ATRIBUCION_ESRI,
    });

    const topografico = L.tileLayer("https://server.arcgisonline.com/ArcGIS/rest/services/World_Topo_Map/MapServer/tile/{z}/{y}/{x}", {
        maxZoom: 18,
        attribution: "Mapa topográfico: " + ATRIBUCION_ESRI,
    });

    // Cuando OpenStreetMap bloquea una página responde con una imagen de aviso (HTTP 403) que el navegador
    // dibuja como si fuera una tesela normal, por eso "tileerror" no sirve: se prueba una tesela al iniciar.
    let osmBloqueado = false;
    const AVISO_OSM =
        "OpenStreetMap bloquea las teselas en esta página (ocurre al abrirla como archivo). Abre el proyecto con Live Server o desde el enlace publicado; mientras tanto se usa la base satelital de Esri.";

    function usarRespaldoOsm() {
        if (map.hasLayer(osm)) {
            map.removeLayer(osm);
            satelite.addTo(map);
        }
        el("visorAviso").textContent = AVISO_OSM; // aviso fijo: los mensajes de estado se sobrescriben
        el("visorAviso").hidden = false;
    }

    fetch("https://tile.openstreetmap.org/0/0/0.png", { referrerPolicy: "origin" })
        .then((respuesta) => {
            osmBloqueado = !respuesta.ok;
            if (osmBloqueado) usarRespaldoOsm();
        })
        .catch(() => {
            osmBloqueado = true;
            usarRespaldoOsm();
        });

    // si OpenStreetMap está bloqueado y el usuario lo elige en el menú, se vuelve a la base de respaldo
    map.on("baselayerchange", (e) => {
        if (e.layer === osm && osmBloqueado) usarRespaldoOsm();
    });

    /* Capas temáticas (se superponen a la base) */

    // Relieve sombreado de Esri: ayuda a leer las formas del terreno
    const relieve = L.tileLayer("https://elevation3d.arcgis.com/arcgis/rest/services/Elevation/World_Hillshade/MapServer/tile/{z}/{y}/{x}", {
        maxZoom: 18,
        maxNativeZoom: 15,
        opacity: 0.55,
        attribution: "Relieve: Esri, USGS, NGA, NASA, CGIAR",
    });

    // Cobertura y uso del suelo: ESA WorldCover 2021 (10 m) por WMS de Terrascope
    const usoSuelo = L.tileLayer.wms("https://mapproxy.terrascope.be/mapproxy/service", {
        layers: "esa-worldcover-map-10m-2021-v2_map",
        format: "image/png",
        transparent: true,
        version: "1.3.0",
        opacity: 0.65,
        attribution: 'Cobertura del suelo: &copy; <a href="https://esa-worldcover.org">ESA WorldCover</a> 2021 (CC BY 4.0) · Terrascope',
    });
    let erroresUso = 0;
    usoSuelo.on("tileerror", () => {
        erroresUso++;
        if (erroresUso === 6) estado("El servicio de uso del suelo (WorldCover) no respondió. Revisa la conexión e intenta activar la capa de nuevo.", "error");
    });
    usoSuelo.on("tileload", () => (erroresUso = 0));

    /* Capas de información */
    const capaMunicipios = L.layerGroup().addTo(map);
    const capaAlineamiento = L.layerGroup().addTo(map);
    const capaPerfil = L.layerGroup().addTo(map);
    const capaTerreno = L.layerGroup(); // pendientes del terreno (se llena al calcularlas)

    L.control
        .layers(
            { "Calles (OpenStreetMap)": osm, "Satélite (Esri)": satelite, "Calles (Esri)": calles, "Topográfico (Esri)": topografico },
            {
                "Municipios (DANE)": capaMunicipios,
                Alineamiento: capaAlineamiento,
                "Pendientes del perfil": capaPerfil,
                "Pendientes del terreno": capaTerreno,
                "Relieve sombreado (Esri)": relieve,
                "Uso del suelo (ESA WorldCover)": usoSuelo,
            },
        )
        .addTo(map);
    L.control.scale({ imperial: false }).addTo(map);

    // La leyenda del uso del suelo solo se muestra mientras la capa está activa
    map.on("overlayadd", (e) => e.layer === usoSuelo && (el("leyendaUso").hidden = false));
    map.on("overlayremove", (e) => e.layer === usoSuelo && (el("leyendaUso").hidden = true));

    /* =====================================================
       2. ALINEAMIENTO: puntos marcados por el usuario
    ===================================================== */

    let municipios = []; // features GeoJSON de /api/municipios (con cota)
    let perfilActual = null; // último perfil calculado
    const marcadores = [];
    const linea = L.polyline([], { color: "#0b0b0b", weight: 3 }).addTo(capaAlineamiento);

    const iconoNumero = (n) => L.divIcon({ className: "vertex-icon", html: `<span>${n}</span>`, iconSize: [26, 26] });

    // Municipio más cercano entre los cargados; si está a más de 150 km se considera que no aplica
    function cercanoCargado(punto) {
        if (!municipios.length) return null;
        const c = A.municipioMasCercano(punto, municipios);
        return c && c.distancia <= 150000 ? c : null;
    }

    function actualizar() {
        const puntos = marcadores.map((m) => m.getLatLng());
        linea.setLatLngs(puntos);

        let total = 0;
        const filas = puntos.map((p, i) => {
            const parcial = i > 0 ? A.haversine(puntos[i - 1], p) : 0;
            total += parcial;
            const m = marcadores[i];
            const cercano = cercanoCargado(p);
            const cota = m.cota === undefined ? "…" : m.cota === null ? "—" : `${m.cota.toFixed(0)} m`;
            const textoMunicipio = cercano ? `${esc(cercano.nombre)} (${(cercano.distancia / 1000).toFixed(1)} km)` : "—";

            m.setIcon(iconoNumero(i + 1));
            m.setPopupContent(
                `<strong>Punto ${i + 1}</strong><br>Lat: ${A.fmtCoord(p.lat)}<br>Lng: ${A.fmtCoord(p.lng)}<br>Cota: ${cota}<br>Municipio más cercano: ${textoMunicipio}`,
            );
            return `<tr><td>${i + 1}</td><td>${A.fmtCoord(p.lat)}</td><td>${A.fmtCoord(p.lng)}</td><td>${i ? A.fmtDist(parcial) : "—"}</td><td>${cota}</td><td>${textoMunicipio}</td></tr>`;
        });

        el("visorCount").textContent = puntos.length;
        el("visorLength").textContent = A.fmtDist(total);
        el("visorRows").innerHTML = filas.length
            ? filas.join("")
            : '<tr><td colspan="6" class="empty">Aún no hay puntos. Haz clic en el mapa para agregarlos.</td></tr>';
    }

    // Consulta a la API la cota de un punto marcado
    async function consultarCota(marcador) {
        const p = marcador.getLatLng();
        marcador.cota = undefined;
        try {
            const respuesta = await API.elevaciones([{ lat: p.lat, lng: p.lng }]);
            marcador.cota = A.validarElevaciones(respuesta.elevaciones, 1) ? respuesta.elevaciones[0] : null;
        } catch (error) {
            marcador.cota = null;
            estado(error.message, "error");
        }
        actualizar();
    }

    function limpiarPerfil() {
        capaPerfil.clearLayers();
        perfilActual = null;
        el("perfilResultados").hidden = true;
    }

    function agregarPunto(latlng) {
        const marcador = L.marker(latlng, { draggable: true, icon: iconoNumero(marcadores.length + 1) }).bindPopup("·").addTo(capaAlineamiento);
        marcador.on("drag", () => linea.setLatLngs(marcadores.map((m) => m.getLatLng())));
        marcador.on("dragend", () => {
            limpiarPerfil();
            actualizar();
            consultarCota(marcador);
        });
        marcadores.push(marcador);
        actualizar();
        consultarCota(marcador);
    }

    map.on("click", (e) => {
        agregarPunto(e.latlng);
        estado(`Punto ${marcadores.length} agregado. Puedes arrastrar los marcadores para ajustarlos.`, "ok");
        limpiarPerfil();
    });

    // Ingreso de coordenadas: valida los datos y agrega el punto al alineamiento
    el("btnCoord").addEventListener("click", () => {
        const texto = (id) => el(id).value.trim().replace(",", ".");
        const lat = texto("coordLat") === "" ? NaN : Number(texto("coordLat"));
        const lng = texto("coordLng") === "" ? NaN : Number(texto("coordLng"));
        if (!Number.isFinite(lat) || !Number.isFinite(lng)) return estado("Escribe latitud y longitud como números (por ejemplo 4.5339 y -75.6811).", "error");
        if (Math.abs(lat) > 85 || Math.abs(lng) > 180) return estado("Latitud entre -85 y 85, y longitud entre -180 y 180.", "error");
        agregarPunto(L.latLng(lat, lng));
        limpiarPerfil();
        map.flyTo([lat, lng], Math.max(map.getZoom(), 13));
        estado(`Punto ${marcadores.length} agregado por coordenadas.`, "ok");
    });

    map.on("mousemove", (e) => {
        el("visorCursor").textContent = `Cursor → Lat: ${A.fmtCoord(e.latlng.lat)} · Lng: ${A.fmtCoord(e.latlng.lng)}`;
    });

    el("visorUndo").addEventListener("click", () => {
        if (!marcadores.length) return estado("No hay puntos para deshacer.", "error");
        capaAlineamiento.removeLayer(marcadores.pop());
        limpiarPerfil();
        actualizar();
        estado("Último punto eliminado.");
    });

    el("visorClear").addEventListener("click", () => {
        marcadores.splice(0).forEach((m) => capaAlineamiento.removeLayer(m));
        limpiarPerfil();
        actualizar();
        estado("Alineamiento limpio. Haz clic en el mapa para marcar nuevos puntos.");
    });

    el("visorFit").addEventListener("click", () => {
        if (marcadores.length > 1) map.fitBounds(linea.getBounds().pad(0.2));
        else if (marcadores.length === 1) map.flyTo(marcadores[0].getLatLng(), 15);
        else map.setView(CENTRO_INICIAL, 11);
    });

    /* =====================================================
       3. MUNICIPIOS (GeoJSON de la API + cotas)
    ===================================================== */

    function popupMunicipio(p) {
        const cota = p.cota_m === null || p.cota_m === undefined ? "—" : `${p.cota_m.toFixed(0)} m`;
        return `<strong>${esc(p.nombre)}</strong><br>Código DANE: ${esc(p.codigo_dane)}<br>Cota: ${cota}<br>Piso térmico: ${esc(p.piso_termico)}`;
    }

    function dibujarMunicipios(geojson) {
        capaMunicipios.clearLayers();
        L.geoJSON(geojson, {
            pointToLayer: (feature, latlng) =>
                L.circleMarker(latlng, {
                    radius: 8,
                    color: "#0b0b0b",
                    weight: 2,
                    fillColor: A.COLOR_PISO[feature.properties.piso_termico],
                    fillOpacity: 0.9,
                    bubblingMouseEvents: false,
                }),
            onEachFeature: (feature, capa) => {
                capa.bindPopup(popupMunicipio(feature.properties));
                capa.bindTooltip(esc(feature.properties.nombre), { permanent: true, direction: "right", offset: [9, 0], className: "etiqueta-mun" });
            },
        }).addTo(capaMunicipios);
    }

    function llenarTablaMunicipios(metadatos) {
        const filas = municipios
            .map((f) => f.properties)
            .sort((a, b) => a.nombre.localeCompare(b.nombre, "es"))
            .map((p) => {
                const cota = p.cota_m === null ? "—" : `${p.cota_m.toFixed(0)} m`;
                return `<tr data-nombre="${esc(p.nombre.toLowerCase())}" data-piso="${esc(p.piso_termico)}"><td>${esc(p.codigo_dane)}</td><td>${esc(p.nombre)}</td><td>${cota}</td><td><i class="punto-piso" style="background:${A.COLOR_PISO[p.piso_termico]}"></i>${esc(p.piso_termico)}</td><td>${p.verificado_dane ? "DANE" : "Local"}</td></tr>`;
            });
        el("municipiosRows").innerHTML = filas.join("");
        el("municipiosFuente").textContent = metadatos ? `Códigos y nombres: ${metadatos.fuente_codigos}. Coordenadas: ${metadatos.fuente_coordenadas}. Cotas: Open-Meteo.` : "";
    }

    // Filtros de la tabla: texto del nombre y piso térmico
    function filtrarTabla() {
        const texto = el("filtroMunicipio").value.trim().toLowerCase();
        const piso = el("filtroPiso").value;
        let visibles = 0;
        document.querySelectorAll("#municipiosRows tr[data-nombre]").forEach((fila) => {
            const mostrar = fila.dataset.nombre.includes(texto) && (!piso || fila.dataset.piso === piso);
            fila.hidden = !mostrar;
            if (mostrar) visibles++;
        });
        el("municipiosConteo").textContent = municipios.length ? `${visibles} de ${municipios.length} municipios` : "";
    }
    el("filtroMunicipio").addEventListener("input", filtrarTabla);
    el("filtroPiso").addEventListener("change", filtrarTabla);

    async function cargarMunicipios(departamento) {
        const geojson = await API.municipios(departamento);
        if (!A.esFeatureCollection(geojson)) throw new Error("La API devolvió los municipios con un formato inesperado.");
        if (!geojson.features.length) throw new Error("El servicio no entregó coordenadas para los municipios de este departamento.");

        // cotas de las cabeceras municipales (en lotes de 100); si falla, se muestran sin cota
        let cotas = [];
        try {
            const puntos = geojson.features.map(A.puntoDeFeature);
            const respuesta = await API.elevacionesPorLotes(puntos);
            if (A.validarElevaciones(respuesta, puntos.length)) cotas = respuesta;
        } catch (error) {
            estado("Municipios cargados sin cotas: " + error.message, "error");
        }

        A.fusionarCotas(geojson.features, cotas);
        municipios = geojson.features;
        dibujarMunicipios(geojson);
        llenarTablaMunicipios(geojson.metadatos);
        filtrarTabla();
        actualizar();
        map.fitBounds(L.geoJSON(geojson).getBounds().pad(0.1));
    }

    el("btnMunicipios").addEventListener("click", async () => {
        const boton = el("btnMunicipios");
        boton.disabled = true;
        estado("Consultando los municipios a la API…", "cargando");
        try {
            await cargarMunicipios(el("selDepartamento").value);
            estado(`${municipios.length} municipios cargados.`, "ok");
        } catch (error) {
            estado("No fue posible cargar los municipios: " + error.message, "error");
        } finally {
            boton.disabled = false;
        }
    });

    /* =====================================================
       4. PERFIL LONGITUDINAL DEL ALINEAMIENTO
    ===================================================== */

    const ANCHO = 700;
    const ALTO = 260;
    const MARGEN = { l: 55, r: 15, t: 15, b: 35 };
    const AREA_W = ANCHO - MARGEN.l - MARGEN.r;
    const AREA_H = ALTO - MARGEN.t - MARGEN.b;
    const marcadorCursor = L.circleMarker([0, 0], { radius: 7, color: "#0b0b0b", fillColor: "#fff", fillOpacity: 1 });

    function escalaPerfil(est) {
        const relleno = Math.max((est.cotaMaxima - est.cotaMinima) * 0.1, 1);
        const bajo = est.cotaMinima - relleno;
        const alto = est.cotaMaxima + relleno;
        return {
            x: (d) => MARGEN.l + (d / est.longitud) * AREA_W,
            y: (z) => MARGEN.t + ((alto - z) / (alto - bajo)) * AREA_H,
            bajo,
            alto,
        };
    }

    function dibujarTramos(muestras, cotas, est) {
        capaPerfil.clearLayers();
        est.pendientes.forEach((pendiente, i) => {
            const clase = A.claseDePendiente(pendiente);
            L.polyline([muestras[i], muestras[i + 1]], { color: clase.color, weight: 6 })
                .bindTooltip(`Pendiente ${pendiente.toFixed(1)} % (${clase.nombre}) · Cota ${cotas[i + 1].toFixed(1)} m`, { sticky: true })
                .addTo(capaPerfil);
        });
    }

    function dibujarEstadisticasPerfil(est, inicio, fin) {
        const tarjetas = [
            ["LONGITUD", A.fmtDist(est.longitud)],
            ["COTA INICIAL", `${est.cotaInicial.toFixed(1)} m`],
            ["COTA FINAL", `${est.cotaFinal.toFixed(1)} m`],
            ["DESNIVEL", `${A.signo(est.desnivel)} m`],
            ["PENDIENTE MEDIA", `${A.signo(est.pendienteMedia)} %`],
            ["PENDIENTE MÁXIMA", `${A.signo(est.pendienteMaxima)} %`],
            ["ASCENSO ACUMULADO", `${est.ascenso.toFixed(1)} m`],
            ["DESCENSO ACUMULADO", `${est.descenso.toFixed(1)} m`],
        ];
        el("perfilStats").innerHTML = tarjetas.map(([t, v]) => `<div class="stat-card"><span>${t}</span><strong>${v}</strong></div>`).join("");

        const clases = ["Suave", "Moderada", "Fuerte"]
            .map((c) => `${c}: ${est.porClase[c].toFixed(0)} %`)
            .join(" · ");
        const cercanos = inicio && fin ? `Municipio más cercano al inicio: ${esc(inicio.nombre)} (${(inicio.distancia / 1000).toFixed(1)} km). Al final: ${esc(fin.nombre)} (${(fin.distancia / 1000).toFixed(1)} km).` : "";
        const eval_ = A.evaluarCorredor(est);
        const pisos = `Piso térmico al inicio: ${A.pisoTermico(est.cotaInicial)}; al final: ${A.pisoTermico(est.cotaFinal)}.`;
        el("perfilResumen").innerHTML =
            `Longitud del trazado por clase de pendiente → ${clases}.<br>${cercanos}<br>${pisos}<br>` +
            `Evaluación preliminar: <strong style="color:${eval_.color}">${eval_.nivel}</strong> (${eval_.texto}).`;
    }

    function dibujarGrafico(muestras, cotas, est) {
        const e = escalaPerfil(est);
        const puntos = muestras.map((m, i) => `${e.x(m.dist).toFixed(1)},${e.y(cotas[i]).toFixed(1)}`);
        let cuadricula = "";
        for (let i = 0; i <= 4; i++) {
            const z = e.bajo + ((e.alto - e.bajo) * i) / 4;
            const d = (est.longitud * i) / 4;
            cuadricula +=
                `<line x1="${MARGEN.l}" x2="${ANCHO - MARGEN.r}" y1="${e.y(z)}" y2="${e.y(z)}" stroke="#e7e7e7"/>` +
                `<text x="${MARGEN.l - 6}" y="${e.y(z) + 3}" text-anchor="end">${z.toFixed(0)}</text>` +
                `<text x="${e.x(d)}" y="${ALTO - 14}" text-anchor="middle">${A.fmtDist(d)}</text>`;
        }
        el("perfilGrafico").innerHTML =
            cuadricula +
            `<polygon points="${MARGEN.l},${MARGEN.t + AREA_H} ${puntos.join(" ")} ${ANCHO - MARGEN.r},${MARGEN.t + AREA_H}" fill="rgba(0,0,0,0.08)"/>` +
            `<polyline points="${puntos.join(" ")}" fill="none" stroke="#0b0b0b" stroke-width="2"/>` +
            `<text x="12" y="${MARGEN.t + 8}">m</text>` +
            `<g id="cursorGrupo" visibility="hidden"><line id="cursorLinea" y1="${MARGEN.t}" y2="${MARGEN.t + AREA_H}" stroke="#0b0b0b" stroke-dasharray="3 3"/>` +
            `<circle id="cursorPunto" r="4" fill="#0b0b0b"/><text id="cursorTexto" y="${MARGEN.t + 10}"></text></g>`;
    }

    // Al pasar el mouse por el perfil se señala el punto equivalente en el mapa
    const grafico = el("perfilGrafico");
    grafico.addEventListener("mousemove", (evento) => {
        if (!perfilActual) return;
        const { muestras, cotas, est } = perfilActual;
        const caja = grafico.getBoundingClientRect();
        const x = ((evento.clientX - caja.left) / caja.width) * ANCHO;
        const fraccion = Math.min(Math.max((x - MARGEN.l) / AREA_W, 0), 1);
        const i = Math.round(fraccion * (muestras.length - 1));
        const e = escalaPerfil(est);
        const px = e.x(muestras[i].dist);
        const py = e.y(cotas[i]);

        el("cursorGrupo").setAttribute("visibility", "visible");
        el("cursorLinea").setAttribute("x1", px);
        el("cursorLinea").setAttribute("x2", px);
        el("cursorPunto").setAttribute("cx", px);
        el("cursorPunto").setAttribute("cy", py);
        const texto = el("cursorTexto");
        texto.setAttribute("x", px > ANCHO / 2 ? px - 6 : px + 6);
        texto.setAttribute("text-anchor", px > ANCHO / 2 ? "end" : "start");
        texto.textContent = `${A.fmtDist(muestras[i].dist)} · ${cotas[i].toFixed(1)} m`;
        marcadorCursor.setLatLng([muestras[i].lat, muestras[i].lng]).addTo(map);
    });
    grafico.addEventListener("mouseleave", () => {
        if (el("cursorGrupo")) el("cursorGrupo").setAttribute("visibility", "hidden");
        map.removeLayer(marcadorCursor);
    });

    el("btnPerfil").addEventListener("click", async () => {
        if (marcadores.length < 2) return estado("Marca al menos 2 puntos en el mapa para trazar un alineamiento.", "error");

        const puntos = marcadores.map((m) => ({ lat: m.getLatLng().lat, lng: m.getLatLng().lng }));
        const muestras = A.puntosSobreLinea(puntos, Number(el("muestreo").value));
        const boton = el("btnPerfil");
        boton.disabled = true;
        estado("Consultando las cotas del trazado a la API…", "cargando");

        try {
            const respuesta = await API.elevaciones(muestras.map(({ lat, lng }) => ({ lat, lng })));
            if (!A.validarElevaciones(respuesta.elevaciones, muestras.length)) throw new Error("La API devolvió las cotas con un formato inesperado.");

            const cotas = respuesta.elevaciones;
            const est = A.estadisticasPerfil(muestras, cotas);
            perfilActual = { puntos, muestras, cotas, est };

            const inicio = cercanoCargado(puntos[0]);
            const fin = cercanoCargado(puntos[puntos.length - 1]);

            dibujarTramos(muestras, cotas, est);
            dibujarEstadisticasPerfil(est, inicio, fin);
            dibujarGrafico(muestras, cotas, est);
            el("perfilResultados").hidden = false;
            activarPestana("paneAlineamiento");
            estado(`Perfil calculado con ${muestras.length} puntos de muestreo.`, "ok");
        } catch (error) {
            estado("No fue posible calcular el perfil: " + error.message, "error");
        } finally {
            boton.disabled = false;
        }
    });

    /* =====================================================
       5. MAPA DE PENDIENTES DEL TERRENO (malla de cotas)
    ===================================================== */

    // límites de la zona visible; las longitudes se normalizan al rango -180..180
    function limitesDeVista() {
        const v = map.getBounds();
        const lng = (x) => ((((x + 180) % 360) + 360) % 360) - 180;
        return {
            sur: Math.max(v.getSouth(), -85),
            norte: Math.min(v.getNorth(), 85),
            oeste: lng(v.getWest()),
            este: lng(v.getEast()),
        };
    }

    function dibujarCeldas(malla, cotas, pendientes) {
        capaTerreno.clearLayers();
        pendientes.forEach((p, k) => {
            const c = malla.puntos[k];
            const clase = A.claseDeTerreno(p);
            L.rectangle(
                [
                    [c.lat - malla.celdaLat / 2, c.lng - malla.celdaLng / 2],
                    [c.lat + malla.celdaLat / 2, c.lng + malla.celdaLng / 2],
                ],
                { stroke: false, fillColor: clase.color, fillOpacity: 0.55 },
            )
                .bindTooltip(`Pendiente ${p.toFixed(1)} % · ${esc(clase.nombre)}<br>Cota ${cotas[k].toFixed(0)} m`, { sticky: true })
                .addTo(capaTerreno);
        });
        if (!map.hasLayer(capaTerreno)) capaTerreno.addTo(map);
    }

    function dibujarResumenTerreno(malla, resumen, cotas) {
        const lado = Math.round(Math.min(malla.dx, malla.dy));
        const aviso = lado < 90 ? " La celda es menor que la resolución del modelo (90 m), por lo que el resultado es aproximado; conviene alejar un poco la vista." : "";
        const tarjetas = [
            ["CELDAS", `${malla.n} × ${malla.n}`],
            ["TAMAÑO DE CELDA", `~${lado} m`],
            ["PENDIENTE MEDIA", `${resumen.media.toFixed(1)} %`],
            ["PENDIENTE MÁXIMA", `${resumen.maxima.toFixed(1)} %`],
            ["COTA MÍNIMA", `${Math.min(...cotas).toFixed(0)} m`],
            ["COTA MÁXIMA", `${Math.max(...cotas).toFixed(0)} m`],
        ];
        const filas = resumen.porClase
            .map((c) => `<tr><td><i class="punto-piso" style="background:${c.color}"></i>${esc(c.nombre)}</td><td>${c.porcentaje.toFixed(1)} %</td></tr>`)
            .join("");
        el("terrenoResultados").innerHTML =
            `<div class="stats-grid">${tarjetas.map(([t, v]) => `<div class="stat-card"><span>${t}</span><strong>${v}</strong></div>`).join("")}</div>` +
            `<div class="viewer-table-wrap"><table class="viewer-table"><thead><tr><th>CLASE DE PENDIENTE</th><th>ÁREA ANALIZADA</th></tr></thead><tbody>${filas}</tbody></table></div>` +
            `<p class="perfil-resumen">Las pendientes se calculan en JavaScript con diferencias centrales sobre una malla de cotas pedida a la API.${aviso}</p>`;
        el("leyendaTerreno").innerHTML = resumen.porClase.map((c) => `<span><i style="background:${c.color}"></i>${esc(c.nombre)}</span>`).join("");
        el("leyendaTerreno").hidden = false;
    }

    el("btnTerreno").addEventListener("click", async () => {
        const n = Number(el("mallaTam").value);
        const limites = limitesDeVista();
        if (limites.este <= limites.oeste) return estado("La vista cruza el meridiano 180°. Mueve el mapa para calcular las pendientes.", "error");
        const malla = A.mallaDeCeldas(limites, n);
        if (Math.max(malla.dx, malla.dy) > 5000) {
            return estado(`La vista es demasiado amplia (celdas de ~${(Math.max(malla.dx, malla.dy) / 1000).toFixed(0)} km). Acerca el mapa para calcular las pendientes.`, "error");
        }
        const boton = el("btnTerreno");
        boton.disabled = true;
        estado("Consultando la malla de cotas a la API…", "cargando");
        try {
            const cotas = await API.elevacionesPorLotes(malla.puntos, 100, (hecho, total) => estado(`Consultando cotas: ${hecho} de ${total} puntos…`, "cargando"));
            if (!A.validarElevaciones(cotas, malla.puntos.length)) throw new Error("La API devolvió las cotas con un formato inesperado.");

            const pendientes = A.pendientesDeMalla(cotas, n, malla.dx, malla.dy);
            const resumen = A.resumenPendientes(pendientes);
            dibujarCeldas(malla, cotas, pendientes);
            dibujarResumenTerreno(malla, resumen, cotas);
            activarPestana("paneTerreno");
            estado(`Mapa de pendientes calculado con ${malla.puntos.length} celdas.`, "ok");
        } catch (error) {
            estado("No fue posible calcular las pendientes: " + error.message, "error");
        } finally {
            boton.disabled = false;
        }
    });

    el("btnLimpiarTerreno").addEventListener("click", () => {
        capaTerreno.clearLayers();
        el("leyendaTerreno").hidden = true;
        el("terrenoResultados").innerHTML = '<p class="empty">Pulsa “Calcular pendientes de la vista” para generar el mapa.</p>';
        estado("Mapa de pendientes eliminado.");
    });

    /* =====================================================
       5b. DESCARGA DEL ALINEAMIENTO (GeoJSON)
    ===================================================== */

    el("btnExportar").addEventListener("click", () => {
        if (!perfilActual) return estado("Calcula primero el perfil del alineamiento.", "error");
        const geojson = A.alineamientoAGeoJSON(perfilActual.puntos, perfilActual.est, A.evaluarCorredor(perfilActual.est));
        const enlace = document.createElement("a");
        enlace.href = URL.createObjectURL(new Blob([JSON.stringify(geojson, null, 2)], { type: "application/geo+json" }));
        enlace.download = "alineamiento_vectorial.geojson";
        enlace.click();
        URL.revokeObjectURL(enlace.href);
        estado("Alineamiento descargado en formato GeoJSON.", "ok");
    });

    /* =====================================================
       6. PESTAÑAS DE RESULTADOS
    ===================================================== */

    function activarPestana(idPanel) {
        document.querySelectorAll(".viewer-tabs button").forEach((b) => {
            const activa = b.dataset.pane === idPanel;
            b.classList.toggle("active", activa);
            b.setAttribute("aria-selected", activa);
        });
        document.querySelectorAll(".viewer-pane").forEach((p) => (p.hidden = p.id !== idPanel));
    }
    document.querySelectorAll(".viewer-tabs button").forEach((b) => b.addEventListener("click", () => activarPestana(b.dataset.pane)));

    /* =====================================================
       7. INICIO
    ===================================================== */

    async function iniciar() {
        actualizar();
        let config;
        try {
            config = await API.configuracion();
            el("apiEstado").textContent = API.modoDirecto()
                ? "Modo directo (sin servidor FastAPI): consultas desde el navegador"
                : "Servidor conectado";
            el("apiEstado").className = "api-estado ok";
        } catch (error) {
            el("apiEstado").textContent = "Servidor sin conexión";
            el("apiEstado").className = "api-estado error";
            estado(error.message, "error");
            return;
        }
        try {
            const { departamentos } = await API.departamentos();
            el("selDepartamento").innerHTML = departamentos.map((d) => `<option value="${esc(d.codigo)}">${esc(d.nombre)}</option>`).join("");
            el("selDepartamento").value = config.departamento.codigo;
        } catch (error) {
            estado("No se pudo cargar la lista de departamentos: " + error.message, "error");
        }
        try {
            await cargarMunicipios(el("selDepartamento").value);
        } catch (error) {
            estado("No fue posible cargar los municipios: " + error.message, "error");
        }
    }

    window.addEventListener("load", () => map.invalidateSize());
    iniciar();
})();
