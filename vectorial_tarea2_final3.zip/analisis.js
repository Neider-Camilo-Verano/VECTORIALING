/* =========================================================
   VECTORIAL - Tarea 2
   Procesamiento en JavaScript de los datos recibidos de la API
   Autor: Neider Camilo Verano Vidales
========================================================= */

(function () {
    const RADIO_TIERRA = 6371008.8; // metros

    /* ===== Validación de las respuestas ===== */

    function esFeatureCollection(objeto) {
        return !!objeto && objeto.type === "FeatureCollection" && Array.isArray(objeto.features);
    }

    function validarElevaciones(cotas, cantidad) {
        return Array.isArray(cotas) && cotas.length === cantidad && cotas.every((c) => Number.isFinite(c));
    }

    function escaparHtml(texto) {
        return String(texto ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
    }

    /* ===== Geometría sobre la esfera ===== */

    // Distancia entre dos puntos {lat, lng} con la fórmula de Haversine (m)
    function haversine(a, b) {
        const rad = Math.PI / 180;
        const dLat = (b.lat - a.lat) * rad;
        const dLng = (b.lng - a.lng) * rad;
        const h = Math.sin(dLat / 2) ** 2 + Math.cos(a.lat * rad) * Math.cos(b.lat * rad) * Math.sin(dLng / 2) ** 2;
        return 2 * RADIO_TIERRA * Math.asin(Math.sqrt(h));
    }

    // Longitud acumulada en cada vértice de una línea
    function longitudAcumulada(puntos) {
        const acumulada = [0];
        for (let i = 1; i < puntos.length; i++) acumulada.push(acumulada[i - 1] + haversine(puntos[i - 1], puntos[i]));
        return acumulada;
    }

    // n puntos equidistantes a lo largo de la línea, con su abscisa (m desde el inicio)
    function puntosSobreLinea(puntos, n) {
        const acumulada = longitudAcumulada(puntos);
        const total = acumulada[acumulada.length - 1];
        const salida = [];
        for (let k = 0; k < n; k++) {
            const d = (total * k) / (n - 1);
            let i = 1;
            while (i < acumulada.length - 1 && acumulada[i] < d) i++;
            const tramo = acumulada[i] - acumulada[i - 1] || 1;
            const t = (d - acumulada[i - 1]) / tramo;
            salida.push({
                lat: puntos[i - 1].lat + (puntos[i].lat - puntos[i - 1].lat) * t,
                lng: puntos[i - 1].lng + (puntos[i].lng - puntos[i - 1].lng) * t,
                dist: d,
            });
        }
        return salida;
    }

    /* ===== Municipios (GeoJSON) ===== */

    // Coordenadas GeoJSON: [longitud, latitud]
    function puntoDeFeature(feature) {
        return { lat: feature.geometry.coordinates[1], lng: feature.geometry.coordinates[0] };
    }

    // Piso térmico según la altitud
    function pisoTermico(cota) {
        if (!Number.isFinite(cota)) return "Sin dato";
        if (cota < 1000) return "Cálido";
        if (cota < 2000) return "Templado";
        if (cota < 3000) return "Frío";
        return "Páramo";
    }

    const COLOR_PISO = { Cálido: "#d84315", Templado: "#f9a825", Frío: "#1565c0", Páramo: "#6a1b9a", "Sin dato": "#777777" };

    // Agrega cota y piso térmico a las propiedades de cada municipio
    function fusionarCotas(features, cotas) {
        features.forEach((f, i) => {
            const cota = Number.isFinite(cotas && cotas[i]) ? cotas[i] : null;
            f.properties.cota_m = cota;
            f.properties.piso_termico = pisoTermico(cota);
        });
    }

    // Municipio más cercano a un punto {lat, lng}
    function municipioMasCercano(punto, municipios) {
        let mejor = null;
        municipios.forEach((f) => {
            const d = haversine(punto, puntoDeFeature(f));
            if (!mejor || d < mejor.distancia) mejor = { nombre: f.properties.nombre, codigo: f.properties.codigo_dane, distancia: d };
        });
        return mejor;
    }

    /* ===== Perfil longitudinal ===== */

    function claseDePendiente(pendiente) {
        const p = Math.abs(pendiente);
        if (p < 5) return { nombre: "Suave", color: "#2e7d32" };
        if (p < 10) return { nombre: "Moderada", color: "#f9a825" };
        return { nombre: "Fuerte", color: "#c62828" };
    }

    function estadisticasPerfil(muestras, cotas) {
        let ascenso = 0;
        let descenso = 0;
        let pendienteMaxima = 0;
        const pendientes = [];
        for (let i = 1; i < muestras.length; i++) {
            const dz = cotas[i] - cotas[i - 1];
            const dd = muestras[i].dist - muestras[i - 1].dist;
            const pendiente = dd > 0 ? (dz / dd) * 100 : 0;
            pendientes.push(pendiente);
            if (dz > 0) ascenso += dz;
            else descenso -= dz;
            if (Math.abs(pendiente) > Math.abs(pendienteMaxima)) pendienteMaxima = pendiente;
        }
        const longitud = muestras[muestras.length - 1].dist;
        const desnivel = cotas[cotas.length - 1] - cotas[0];

        // porcentaje de la longitud en cada clase de pendiente
        const porClase = { Suave: 0, Moderada: 0, Fuerte: 0 };
        pendientes.forEach((p, i) => {
            porClase[claseDePendiente(p).nombre] += muestras[i + 1].dist - muestras[i].dist;
        });
        Object.keys(porClase).forEach((k) => (porClase[k] = longitud > 0 ? (porClase[k] / longitud) * 100 : 0));

        return {
            longitud,
            cotaInicial: cotas[0],
            cotaFinal: cotas[cotas.length - 1],
            cotaMinima: Math.min(...cotas),
            cotaMaxima: Math.max(...cotas),
            desnivel,
            ascenso,
            descenso,
            pendienteMedia: longitud > 0 ? (desnivel / longitud) * 100 : 0,
            pendienteMaxima,
            pendientes,
            porClase,
        };
    }

    /* ===== Mapa de pendientes del terreno (malla de cotas) ===== */

    // Clases de pendiente del terreno (en %), de menos a más inclinada
    const CLASES_TERRENO = [
        { max: 5, nombre: "Plana a suave (< 5 %)", color: "#2e7d32" },
        { max: 10, nombre: "Ondulada (5 – 10 %)", color: "#c0ca33" },
        { max: 20, nombre: "Inclinada (10 – 20 %)", color: "#f9a825" },
        { max: 35, nombre: "Muy inclinada (20 – 35 %)", color: "#ef6c00" },
        { max: Infinity, nombre: "Escarpada (> 35 %)", color: "#b71c1c" },
    ];

    function claseDeTerreno(pendiente) {
        return CLASES_TERRENO.find((c) => Math.abs(pendiente) < c.max);
    }

    // Malla de n x n puntos al centro de cada celda; la fila 0 es la más al norte
    function mallaDeCeldas(limites, n) {
        const celdaLat = (limites.norte - limites.sur) / n;
        const celdaLng = (limites.este - limites.oeste) / n;
        const puntos = [];
        for (let i = 0; i < n; i++) {
            for (let j = 0; j < n; j++) {
                puntos.push({ lat: limites.norte - (i + 0.5) * celdaLat, lng: limites.oeste + (j + 0.5) * celdaLng });
            }
        }
        const centro = puntos[Math.floor(n / 2) * n + Math.floor(n / 2)];
        const dx = haversine(centro, { lat: centro.lat, lng: centro.lng + celdaLng });
        const dy = haversine(centro, { lat: centro.lat + celdaLat, lng: centro.lng });
        return { puntos, n, celdaLat, celdaLng, dx, dy };
    }

    // Pendiente en % de cada celda con diferencias centrales (en los bordes, diferencia simple)
    function pendientesDeMalla(cotas, n, dx, dy) {
        const z = (i, j) => cotas[i * n + j];
        const resultado = [];
        for (let i = 0; i < n; i++) {
            for (let j = 0; j < n; j++) {
                const j0 = Math.max(j - 1, 0);
                const j1 = Math.min(j + 1, n - 1);
                const i0 = Math.max(i - 1, 0);
                const i1 = Math.min(i + 1, n - 1);
                const dzdx = (z(i, j1) - z(i, j0)) / ((j1 - j0) * dx);
                // la fila 0 está al norte, por eso el signo no cambia la magnitud
                const dzdy = (z(i1, j) - z(i0, j)) / ((i1 - i0) * dy);
                resultado.push(Math.sqrt(dzdx * dzdx + dzdy * dzdy) * 100);
            }
        }
        return resultado;
    }

    function resumenPendientes(pendientes) {
        const total = pendientes.length;
        const porClase = CLASES_TERRENO.map((c) => ({ nombre: c.nombre, color: c.color, porcentaje: 0 }));
        pendientes.forEach((p) => {
            porClase[CLASES_TERRENO.indexOf(claseDeTerreno(p))].porcentaje += 100 / total;
        });
        return {
            media: pendientes.reduce((s, p) => s + p, 0) / total,
            maxima: Math.max(...pendientes),
            porClase,
        };
    }

    /* ===== Evaluación preliminar y exportación del alineamiento ===== */

    // Criterio de referencia definido para el visor: según el % de la longitud con pendiente fuerte
    function evaluarCorredor(est) {
        const fuerte = est.porClase.Fuerte;
        if (fuerte < 10) return { nivel: "Favorable", color: "#2e7d32", texto: "menos del 10 % del trazado tiene pendiente fuerte" };
        if (fuerte < 30) return { nivel: "Con tramos exigentes", color: "#f9a825", texto: "entre el 10 % y el 30 % del trazado tiene pendiente fuerte" };
        return { nivel: "Exigente", color: "#c62828", texto: "el 30 % o más del trazado tiene pendiente fuerte" };
    }

    // GeoJSON del alineamiento (LineString) con el resumen del perfil en sus propiedades
    function alineamientoAGeoJSON(puntos, est, evaluacion) {
        return {
            type: "FeatureCollection",
            features: [
                {
                    type: "Feature",
                    geometry: { type: "LineString", coordinates: puntos.map((p) => [p.lng, p.lat]) }, // GeoJSON: [lng, lat]
                    properties: {
                        proyecto: "VECTORIAL - alineamiento preliminar",
                        longitud_m: Number(est.longitud.toFixed(2)),
                        cota_inicial_m: Number(est.cotaInicial.toFixed(1)),
                        cota_final_m: Number(est.cotaFinal.toFixed(1)),
                        desnivel_m: Number(est.desnivel.toFixed(1)),
                        pendiente_media_pct: Number(est.pendienteMedia.toFixed(2)),
                        pendiente_maxima_pct: Number(est.pendienteMaxima.toFixed(2)),
                        porcentaje_pendiente_fuerte: Number(est.porClase.Fuerte.toFixed(1)),
                        evaluacion_preliminar: evaluacion.nivel,
                    },
                },
            ],
        };
    }

    /* ===== Formato de números ===== */

    const fmtDist = (m) => (m < 1000 ? `${m.toFixed(1)} m` : `${(m / 1000).toFixed(3)} km`);
    const fmtCoord = (v) => v.toFixed(6);
    const signo = (v, decimales = 1) => (v > 0 ? "+" : "") + v.toFixed(decimales);

    const exportado = {
        esFeatureCollection,
        validarElevaciones,
        escaparHtml,
        haversine,
        longitudAcumulada,
        puntosSobreLinea,
        puntoDeFeature,
        pisoTermico,
        COLOR_PISO,
        fusionarCotas,
        municipioMasCercano,
        claseDePendiente,
        estadisticasPerfil,
        CLASES_TERRENO,
        claseDeTerreno,
        mallaDeCeldas,
        pendientesDeMalla,
        resumenPendientes,
        evaluarCorredor,
        alineamientoAGeoJSON,
        fmtDist,
        fmtCoord,
        signo,
    };

    (typeof window !== "undefined" ? window : globalThis).VectorialAnalisis = exportado;
    if (typeof module !== "undefined") module.exports = exportado;
})();
