@echo off
cd /d "%~dp0"
if not exist .venv (
    python -m venv .venv
)
call .venv\Scripts\activate
pip install -r servidor\requirements.txt
start "" http://127.0.0.1:8000
python -m uvicorn servidor.main:app --port 8000
pause
